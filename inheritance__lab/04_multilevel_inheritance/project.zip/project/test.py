from project.car import Car
from project.vehicle import Vehicle
from project.sports_car import SportsCar

bmw = SportsCar()
print(bmw.move())
print(bmw.drive())
print(bmw.race())
