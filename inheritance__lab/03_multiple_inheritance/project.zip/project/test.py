from project.employee import Employee
from project.person import Person
from project.teacher import Teacher

pesho = Teacher()
print(pesho.sleep())
print(pesho.get_fired())
print(pesho.teach())